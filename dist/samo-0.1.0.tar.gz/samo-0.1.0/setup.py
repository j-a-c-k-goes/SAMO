# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['samo']

package_data = \
{'': ['*'], 'samo': ['wordlists/*']}

install_requires = \
['aiohttp==3.7.4.post0',
 'async-timeout==3.0.1',
 'attrs==22.1.0',
 'certifi>=2022.12.7,<2023.0.0',
 'chardet==4.0.0',
 'discord-py>=2.1.0,<3.0.0',
 'idna==3.4',
 'meson==0.63.2',
 'multidict==6.0.2',
 'python-discord==1.7.3',
 'python-dotenv==0.21.0',
 'typing-extensions==4.3.0',
 'yarl==1.8.1']

setup_kwargs = {
    'name': 'samo',
    'version': '0.1.0',
    'description': "SAMO® is a bot-version of Jean-Michel Basquiat's SAMO quotes. The bot generates content from a wordlist.",
    'long_description': '# SAMO®\nVersion: 0.1.0\nAuthor: [Jack](https://github.com/j-a-c-k-goes)\nOperating at: [W3BBIE Discord](https://discord.gg/ZZ7GeKPy)\n*README coming soon 😊*\n',
    'author': 'Jack',
    'author_email': 'jack@flnpb.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
