# SAMO®
Version: 0.1.0
Author: [Jack](https://github.com/j-a-c-k-goes)
Operating at: [W3BBIE Discord](https://discord.gg/ZZ7GeKPy)
*README coming soon 😊*
